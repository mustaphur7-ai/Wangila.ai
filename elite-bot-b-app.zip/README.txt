ELITE BOT B (installable phone app)

FILES (upload ALL 5 to the SAME place, no folders):
  index.html              the bot itself (Bot B, original rules, auto-run)
  manifest.webmanifest    install information
  sw.js                   keeps the app files so it opens offline
  icon-192.png, icon-512.png   the app icon

PUT IT ONLINE (free, from your phone)
 1. github.com -> sign up -> New repository (Public). For the shortest link name it  YOURUSERNAME.github.io
 2. Add file -> Upload files -> pick all 5 files -> Commit changes
 3. Settings -> Pages -> Deploy from a branch -> main / root -> Save
 4. After 1 to 2 minutes open  https://YOURUSERNAME.github.io/  in Chrome

INSTALL ON YOUR PHONE
 Tap the Install app button at the top (or Chrome menu -> Install app / Add to Home screen).
 You get an icon "Elite Bot B" that opens full screen.

NOTES
 - The app needs internet to trade. Offline it only opens the screen.
 - Chrome slows down apps that are not on screen. Keep the app open and the screen on while the bot runs.
 - To update later, upload the new file with the same name. The app picks it up the next time it opens online.
 - Use a broker DEMO account first.
